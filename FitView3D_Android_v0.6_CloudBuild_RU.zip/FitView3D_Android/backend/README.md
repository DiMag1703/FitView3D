# FitView 3D backend v0.3

## API
- `GET /health`: confirms API availability and whether a provider is configured.
- `POST /api/tryon`: multipart form fields `person_image` and `garment_image`.
- Validates image MIME/type, format, size and dimensions.
- Default mode intentionally returns HTTP 503 until a real model adapter is configured. It never pretends a preview is an AI result.

## Run locally
```bash
cd backend
python -m venv .venv
# Windows: .venv\\Scripts\\activate
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
uvicorn main:app --host 0.0.0.0 --port 8000
```
Open `http://127.0.0.1:8000/health`. For Android emulator, use `http://10.0.2.2:8000`; for a physical phone, use the computer's LAN IP or a deployed HTTPS URL. Android WebView's mixed-content/network policy may require HTTPS for production. Never expose a development server to the public internet.

## Model choice for free testing
**Recommended first experiment: CatVTON**, self-hosted for non-commercial testing only. The upstream repository says the model is released under CC BY-NC-SA 4.0 and reports under 8 GB VRAM for 1024x768 inference in a supported setup. That is a repository claim, not a guarantee for every GPU/driver combination. Read the upstream license and model-weight terms before use:
https://github.com/Zheng-Chong/CatVTON

Installation guidance in upstream README uses Python 3.9 and a CUDA-capable GPU. A compatible NVIDIA GPU with around 8 GB VRAM may be sufficient for the documented configuration, but dependencies, precision and preprocessing affect actual requirements. Cloud GPU sessions may not be free or continuously available.

Alternative: IDM-VTON is also CC BY-NC-SA 4.0 and needs its own model checkpoints and preprocessing dependencies:
https://github.com/yisol/IDM-VTON

## Integration status
This repository contains the API contract and upload-validation flow. **The CatVTON inference adapter is not bundled or activated yet.** It needs model weights, CUDA/PyTorch compatibility checks, upstream preprocessing, a reviewed adapter, and secure result delivery. The API deliberately returns 503 when no provider is configured.

## Security/privacy before real users
- Use HTTPS; authenticate and rate-limit requests.
- Keep uploads private and outside static web roots.
- Set a scheduled cleanup for expired output files and handle deletion requests.
- Do not log image bytes, names, public URLs, or sensitive personal data.
- Obtain explicit consent before transmitting a person's photo to a server.
- Avoid claiming the generated image guarantees size, fit, fabric behavior or color accuracy.
- Review upstream licenses for both source code and model weights before commercial use.

## If you only have an Android phone
The FastAPI backend in this repository cannot run directly on a normal Android phone as a GPU inference server. Use the app's **Открыть бесплатное онлайн-демо** button to test the model in a hosted browser demo. This is only a temporary test path; it does not make the hosted model part of the app or return its result to the app automatically.

import os
import secrets
from pathlib import Path
from typing import Annotated

from fastapi import FastAPI, File, HTTPException, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from PIL import Image, UnidentifiedImageError

ROOT = Path(__file__).resolve().parent
UPLOAD_DIR = Path(os.getenv("FITVIEW_UPLOAD_DIR", ROOT / "private_uploads")).resolve()
RESULT_DIR = Path(os.getenv("FITVIEW_RESULT_DIR", ROOT / "results")).resolve()
MAX_BYTES = int(os.getenv("FITVIEW_MAX_IMAGE_MB", "12")) * 1024 * 1024
MAX_SIDE = int(os.getenv("FITVIEW_MAX_IMAGE_SIDE", "6000"))
PROVIDER = os.getenv("FITVIEW_TRYON_PROVIDER", "none").lower()

UPLOAD_DIR.mkdir(parents=True, exist_ok=True)
RESULT_DIR.mkdir(parents=True, exist_ok=True)

app = FastAPI(title="FitView 3D Try-On API", version="0.3.0")
app.add_middleware(
    CORSMiddleware,
    allow_origins=os.getenv("FITVIEW_ALLOWED_ORIGINS", "http://localhost").split(","),
    allow_credentials=False,
    allow_methods=["GET", "POST"],
    allow_headers=["*"],
)
# Result files are intentionally not mounted publicly by default.

@app.get("/health")
def health():
    return {
        "status": "ok",
        "provider": PROVIDER,
        "ai_ready": PROVIDER != "none",
        "message": "AI provider must be configured before generating results."
    }

async def save_valid_image(upload: UploadFile, prefix: str) -> Path:
    if not upload.content_type or not upload.content_type.startswith("image/"):
        raise HTTPException(status_code=415, detail=f"{prefix}: only image uploads are accepted")
    raw = await upload.read(MAX_BYTES + 1)
    if len(raw) > MAX_BYTES:
        raise HTTPException(status_code=413, detail=f"{prefix}: image exceeds upload limit")
    try:
        from io import BytesIO
        with Image.open(BytesIO(raw)) as im:
            im.verify()
        with Image.open(BytesIO(raw)) as im:
            if im.width > MAX_SIDE or im.height > MAX_SIDE:
                raise HTTPException(status_code=413, detail=f"{prefix}: image dimensions are too large")
            if im.width < 128 or im.height < 128:
                raise HTTPException(status_code=422, detail=f"{prefix}: image is too small")
            fmt = (im.format or "").lower()
            ext = {"jpeg": ".jpg", "png": ".png", "webp": ".webp"}.get(fmt)
            if not ext:
                raise HTTPException(status_code=415, detail=f"{prefix}: use JPEG, PNG, or WebP")
    except UnidentifiedImageError:
        raise HTTPException(status_code=415, detail=f"{prefix}: invalid image file")
    except OSError:
        raise HTTPException(status_code=415, detail=f"{prefix}: invalid or damaged image file")

    path = UPLOAD_DIR / f"{prefix}_{secrets.token_hex(16)}{ext}"
    path.write_bytes(raw)
    return path

@app.post("/api/tryon")
async def tryon(
    person_image: Annotated[UploadFile, File(description="Person photo, preferably full body")],
    garment_image: Annotated[UploadFile, File(description="Garment product photo")],
):
    # Save only after validating each upload. Configure a private storage lifecycle in deployment.
    person_path = await save_valid_image(person_image, "person")
    garment_path = await save_valid_image(garment_image, "garment")

    if PROVIDER == "none":
        # Do not return a fake result: clearly report that inference isn't configured.
        for p in (person_path, garment_path):
            p.unlink(missing_ok=True)
        raise HTTPException(
            status_code=503,
            detail=(
                "AI provider is not configured yet. Set FITVIEW_TRYON_PROVIDER and "
                "implement the matching provider adapter. CatVTON is documented in backend/README.md."
            ),
        )

    # Provider adapters must return a path to a generated image. We intentionally fail closed
    # until a reviewed adapter is installed, rather than implying an AI result exists.
    try:
        from provider import generate_tryon
        output_path = await generate_tryon(person_path, garment_path, RESULT_DIR)
        if not output_path or not Path(output_path).is_file():
            raise RuntimeError("Provider returned no result file")
        # Result delivery/auth and expiry should be implemented before public deployment.
        raise HTTPException(
            status_code=501,
            detail="Inference adapter returned an image, but secure result delivery is not configured."
        )
    except HTTPException:
        raise
    except Exception as exc:
        raise HTTPException(status_code=502, detail=f"AI provider failed: {type(exc).__name__}") from exc
    finally:
        # Uploaded originals are deleted after inference attempt.
        person_path.unlink(missing_ok=True)
        garment_path.unlink(missing_ok=True)

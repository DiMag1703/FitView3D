"""
Provider adapter contract for FitView 3D.

Implement this file as `provider.py` only after choosing and installing a model.
The function should call the actual inference implementation and return a Path
to a generated image saved under output_dir. Do not return the input photo as
if it were a generated result.
"""
from pathlib import Path

async def generate_tryon(person_path: Path, garment_path: Path, output_dir: Path) -> Path:
    raise NotImplementedError(
        "Connect a reviewed AI virtual try-on model here (e.g. self-hosted CatVTON for non-commercial testing)."
    )
